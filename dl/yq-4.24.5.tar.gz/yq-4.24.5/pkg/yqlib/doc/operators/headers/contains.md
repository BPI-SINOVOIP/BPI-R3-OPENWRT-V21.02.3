# Contains

This returns `true` if the context contains the passed in parameter, and false otherwise.
