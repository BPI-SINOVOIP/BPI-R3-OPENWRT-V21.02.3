# Delete

Deletes matching entries in maps or arrays.
