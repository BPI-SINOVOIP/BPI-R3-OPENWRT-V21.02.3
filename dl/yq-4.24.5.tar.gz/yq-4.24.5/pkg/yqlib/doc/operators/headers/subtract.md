# Subtract

You can use subtract to subtract numbers, as well as removing elements from an array.
