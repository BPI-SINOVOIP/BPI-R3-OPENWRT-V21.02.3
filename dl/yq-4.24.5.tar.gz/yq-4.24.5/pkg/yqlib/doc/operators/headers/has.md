# Has

This is operation that returns true if the key exists in a map (or index in an array), false otherwise.
