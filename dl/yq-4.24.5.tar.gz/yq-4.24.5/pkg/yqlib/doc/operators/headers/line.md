# Line

Returns the line of the matching node. Starts from 1, 0 indicates there was no line data.
