# Flatten
This recursively flattens arrays.
