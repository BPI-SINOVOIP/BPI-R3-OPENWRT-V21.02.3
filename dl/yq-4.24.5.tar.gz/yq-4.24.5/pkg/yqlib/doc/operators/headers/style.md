# Style

The style operator can be used to get or set the style of nodes (e.g. string style, yaml style)
