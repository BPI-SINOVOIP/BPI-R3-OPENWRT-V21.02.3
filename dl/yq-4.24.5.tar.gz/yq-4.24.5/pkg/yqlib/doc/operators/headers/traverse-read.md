# Traverse (Read)

This is the simplest (and perhaps most used) operator, it is used to navigate deeply into yaml structures.
