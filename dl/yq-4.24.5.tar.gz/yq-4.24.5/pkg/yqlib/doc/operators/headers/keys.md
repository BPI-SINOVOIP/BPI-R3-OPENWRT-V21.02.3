# Keys

Use the `keys` operator to return map keys or array indices. 
