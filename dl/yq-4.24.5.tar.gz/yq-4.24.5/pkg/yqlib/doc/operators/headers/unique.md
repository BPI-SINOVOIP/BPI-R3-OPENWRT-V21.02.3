# Unique

This is used to filter out duplicated items in an array.
