# Length

Returns the lengths of the nodes. Length is defined according to the type of the node.
