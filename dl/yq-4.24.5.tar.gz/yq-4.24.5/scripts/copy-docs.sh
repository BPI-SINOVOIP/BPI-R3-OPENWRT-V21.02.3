#!/bin/bash

cp how-it-works.md ../yq-gitbook/.
cp pkg/yqlib/doc/operators/*.md ../yq-gitbook/operators/.
cp pkg/yqlib/doc/usage/*.md ../yq-gitbook/usage/.