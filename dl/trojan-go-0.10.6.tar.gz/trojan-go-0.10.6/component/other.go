//go:build other || full
// +build other full

package build

import (
	_ "github.com/p4gefau1t/trojan-go/easy"
	_ "github.com/p4gefau1t/trojan-go/url"
)
