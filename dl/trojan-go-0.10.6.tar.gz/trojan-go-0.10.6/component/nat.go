//go:build nat || full || mini
// +build nat full mini

package build

import (
	_ "github.com/p4gefau1t/trojan-go/proxy/nat"
)
