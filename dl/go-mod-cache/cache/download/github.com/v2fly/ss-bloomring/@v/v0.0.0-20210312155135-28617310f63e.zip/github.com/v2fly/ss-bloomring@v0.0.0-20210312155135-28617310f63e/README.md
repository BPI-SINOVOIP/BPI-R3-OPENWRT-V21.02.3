# ss-bloomring
A cherry-picked bloomring from go-shadowsocks2

Thanks!