//go:build tools
// +build tools

package quic

import (
	_ "github.com/cheekybits/genny"
	_ "github.com/onsi/ginkgo/ginkgo"
)
