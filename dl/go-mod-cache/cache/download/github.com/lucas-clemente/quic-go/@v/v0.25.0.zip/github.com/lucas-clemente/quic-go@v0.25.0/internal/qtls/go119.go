//go:build go1.19
// +build go1.19

package qtls

var _ int = "quic-go doesn't build on Go 1.19 yet."
