void error_exit(char *format, ...);
