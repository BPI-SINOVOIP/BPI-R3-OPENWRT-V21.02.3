int connect_to(struct hostent *host, int portnr, int timeout);
