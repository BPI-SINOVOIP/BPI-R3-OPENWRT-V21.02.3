#ifndef TRAFFIC_H
#define TRAFFIC_H

void trafficmeter(char iface[], int sampletime);
void livetrafficmeter(char iface[], int mode);

#endif
