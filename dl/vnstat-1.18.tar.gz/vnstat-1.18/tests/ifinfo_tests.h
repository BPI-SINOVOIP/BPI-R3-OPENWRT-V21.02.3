#ifndef IFINFO_TESTS_H
#define IFINFO_TESTS_H

void add_ifinfo_tests(Suite *s);

#endif
