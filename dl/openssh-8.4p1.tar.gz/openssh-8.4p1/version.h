/* $OpenBSD: version.h,v 1.88 2020/09/27 07:22:05 djm Exp $ */

#define SSH_VERSION	"OpenSSH_8.4"

#define SSH_PORTABLE	"p1"
#define SSH_RELEASE	SSH_VERSION SSH_PORTABLE
