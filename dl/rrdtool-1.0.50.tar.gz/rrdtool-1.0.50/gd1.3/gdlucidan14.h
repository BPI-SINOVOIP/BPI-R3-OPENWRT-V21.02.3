
#ifndef _GDLUCIDAN14_H_
#define _GDLUCIDAN14_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Medium-R-Normal-Sans-14-140-75-75-M-90-ISO8859-1
	at Tue Jul 13 15:35:10 1999.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaNormal14;

#endif

