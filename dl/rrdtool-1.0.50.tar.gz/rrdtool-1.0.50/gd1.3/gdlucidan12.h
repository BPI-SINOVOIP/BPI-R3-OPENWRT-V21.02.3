
#ifndef _GDLUCIDAN12_H_
#define _GDLUCIDAN12_H_ 1

/*
	This is a header file for gd font, generated using
	bdftogd version 0.51 by Jan Pazdziora, adelton@fi.muni.cz
	from bdf font
	-B&H-LucidaTypewriter-Medium-R-Normal-Sans-12-120-75-75-M-70-ISO8859-1
	at Tue Jul 13 15:33:27 1999.
	The original bdf was holding following copyright:
	"Copyright Bigelow & Holmes 1986, 1985."
 */


#include "gd.h"

extern gdFontPtr gdLucidaNormal12;

#endif

