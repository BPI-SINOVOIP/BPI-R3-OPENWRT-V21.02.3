wslay_event_get_close_sent
==========================

SYNOPSIS
--------

#include <wslay/wslay.h>

.. c:function:: int wslay_event_get_close_sent(wslay_event_context_ptr ctx)

DESCRIPTION
-----------

:c:func:`wslay_event_get_close_sent` returns 1 if a close control frame
has been sent to peer, or returns 0.

SEE ALSO
--------

:c:func:`wslay_event_get_close_sent`
