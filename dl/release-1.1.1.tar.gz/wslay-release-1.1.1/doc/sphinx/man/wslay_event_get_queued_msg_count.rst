wslay_event_get_queued_msg_count
================================

SYNOPSIS
--------

#include <wslay/wslay.h>

.. c:function:: size_t wslay_event_get_queued_msg_count(wslay_event_context_ptr ctx)

DESCRIPTION
-----------

:c:func:`wslay_event_get_queued_msg_count` returns the number of queued
messages.
