// SPDX-License-Identifier: GPL-2.0
/* Copyright (C) B.A.T.M.A.N. contributors:
 *
 * Sven Eckelmann
 */

#define CREATE_TRACE_POINTS
#include "trace.h"
