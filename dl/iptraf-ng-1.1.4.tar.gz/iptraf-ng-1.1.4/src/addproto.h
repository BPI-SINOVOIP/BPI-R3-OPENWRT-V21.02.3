#ifndef IPTRAF_NG_ADDPROTO_H
#define IPTRAF_NG_ADDPROTO_H

#ifndef IPPROTO_IGP
#define IPPROTO_IGP		9
#endif

#ifndef IPPROTO_IGRP
#define IPPROTO_IGRP		88
#endif

#ifndef IPPROTO_OSPFIGP
#define IPPROTO_OSPFIGP		89
#endif

#ifndef IPPROTO_GRE
#define IPPROTO_GRE		47
#endif

#ifndef IPPROTO_IPSEC_AH
#define IPPROTO_IPSEC_AH	51
#endif

#ifndef IPPROTO_IPSEC_ESP
#define IPPROTO_IPSEC_ESP	50
#endif

#endif	/* IPTRAF_NG_ADDPROTO_H */
