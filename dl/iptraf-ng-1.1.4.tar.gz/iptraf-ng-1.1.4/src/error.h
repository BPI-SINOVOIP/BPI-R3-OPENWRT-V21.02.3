#ifndef IPTRAF_NG_ERROR_H
#define IPTRAF_NG_ERROR_H

void write_error(char *msg, ...) __printf(1,2);

#endif	/* IPTRAF_NG_ERROR_H */
