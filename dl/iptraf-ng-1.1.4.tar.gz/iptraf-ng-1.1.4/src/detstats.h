#ifndef IPTRAF_NG_DETSTATS_H
#define IPTRAF_NG_DETSTATS_H

void detstats(char *iface, time_t facilitytime);

#endif /* IPTRAF_NG_DETSTATS_H */
