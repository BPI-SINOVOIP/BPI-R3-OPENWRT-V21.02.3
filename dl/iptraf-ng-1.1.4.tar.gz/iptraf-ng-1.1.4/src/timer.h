#ifndef IPTRAF_NG_TIMER_H
#define IPTRAF_NG_TIMER_H

void printelapsedtime(time_t start, time_t now, int y, int x, WINDOW * win);

#endif	/* IPTRAF_NG_TIMER_H */
