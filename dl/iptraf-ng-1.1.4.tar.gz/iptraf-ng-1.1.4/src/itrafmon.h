#ifndef IPTRAF_NG_ITRAFMON_H
#define IPTRAF_NG_ITRAFMON_H

void ipmon(time_t facilitytime, char *ifptr);

#endif /* IPTRAF_NG_ITRAFMON_H */
