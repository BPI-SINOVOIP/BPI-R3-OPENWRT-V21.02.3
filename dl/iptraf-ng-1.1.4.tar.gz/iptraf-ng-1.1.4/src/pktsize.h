#ifndef IPTRAF_NG_PKTSIZE_H
#define IPTRAF_NG_PKTSIZE_H

void packet_size_breakdown(char *iface, time_t facilitytime);

#endif	/* IPTRAF_NG_PKTSIZE_H */
