/* For terms of usage/redistribution/modification see the LICENSE file */
/* For authors and contributors see the AUTHORS file */

#ifndef IPTRAF_NG_BUILT_IN_H
#define IPTRAF_NG_BUILT_IN_H

int cmd_capture(int argc, char **argv);

#endif
