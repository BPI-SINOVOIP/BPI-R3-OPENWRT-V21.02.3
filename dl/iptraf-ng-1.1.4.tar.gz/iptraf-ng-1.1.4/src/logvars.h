#ifndef IPTRAF_NG_LOGVARS_H
#define IPTRAF_NG_LOGVARS_H

extern int rotate_flag;
extern char target_logname[160];
extern char current_logfile[160];

#endif	/* IPTRAF_NG_LOGVARS_H */
