package configs

type NamespaceType string

type Namespaces []Namespace
