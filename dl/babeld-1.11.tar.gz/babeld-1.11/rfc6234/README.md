rfc6234 RFC6234 US Secure Hash Algorithms - Example Code Extract
================================================================

These are the code examples given in the IETF RFC6234:
  http://tools.ietf.org/html/rfc6234

