#ifndef _NETINET_IN_SYSTM_H
#define _NETINET_IN_SYSTM_H

#include <stdint.h>

typedef uint16_t n_short;
typedef uint32_t n_long, n_time;

#endif
