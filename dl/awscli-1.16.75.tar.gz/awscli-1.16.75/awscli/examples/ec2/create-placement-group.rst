**To create a placement group**

This example command creates a placement group with the specified name.

Command::

  aws ec2 create-placement-group --group-name my-cluster --strategy cluster
