#define __NR_io_setup		398
#define __NR_io_destroy		399
#define __NR_io_getevents	400
#define __NR_io_submit		401
#define __NR_io_cancel		402
