Authors
=======
* Bruce Geng (gengw2000[at]163[dot]com) authored the OpenWrt port-mirroring package in 2012 and published it on https://code.google.com/p/port-mirroring.
* Mike Maraya (mike[dot]maraya[at]gmail[dot]com) imported the code in 2015 to https://github.com/mmaraya/port-mirroring and maintained version 1.4 and later. 
* Other contributors to this software are:
  * Your Name Here (your obfuscated email address here)

